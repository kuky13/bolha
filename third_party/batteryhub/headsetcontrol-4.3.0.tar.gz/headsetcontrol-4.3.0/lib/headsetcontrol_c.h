/**
 * @file headsetcontrol_c.h
 * @brief C API for HeadsetControl library
 *
 * This header provides a pure C interface for controlling USB headsets.
 * It wraps the C++ library with an opaque handle-based API.
 *
 * Example usage:
 * @code
 * #include <headsetcontrol_c.h>
 * #include <stdio.h>
 *
 * int main() {
 *     // Discover headsets
 *     hsc_headset_t* headsets = NULL;
 *     int count = hsc_discover(&headsets);
 *
 *     for (int i = 0; i < count; i++) {
 *         printf("Found: %s\n", hsc_get_name(headsets[i]));
 *
 *         // Check battery
 *         if (hsc_supports(headsets[i], HSC_CAP_BATTERY_STATUS)) {
 *             hsc_battery_t battery;
 *             if (hsc_get_battery(headsets[i], &battery) == HSC_RESULT_OK) {
 *                 printf("Battery: %d%%\n", battery.level_percent);
 *             }
 *         }
 *     }
 *
 *     // Cleanup
 *     hsc_free_headsets(headsets, count);
 *     return 0;
 * }
 * @endcode
 */

#ifndef HEADSETCONTROL_C_H
#define HEADSETCONTROL_C_H

#include <stdbool.h>
#include <stdint.h>

/* DLL export/import macros for Windows */
#ifdef _WIN32
#ifdef HSC_BUILDING_DLL
#define HSC_API __declspec(dllexport)
#elif defined(HSC_DLL)
#define HSC_API __declspec(dllimport)
#else
#define HSC_API
#endif
#else
#define HSC_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* ============================================================================
 * Opaque Types
 * ============================================================================ */

/** Opaque headset handle */
typedef void* hsc_headset_t;

/* ============================================================================
 * Error Codes
 * ============================================================================ */

typedef enum {
    HSC_RESULT_OK             = 0, /**< Success */
    HSC_RESULT_ERROR          = -1, /**< Generic error */
    HSC_RESULT_NOT_SUPPORTED  = -2, /**< Feature not supported */
    HSC_RESULT_DEVICE_OFFLINE = -3, /**< Device is offline */
    HSC_RESULT_TIMEOUT        = -4, /**< Operation timed out */
    HSC_RESULT_HID_ERROR      = -5, /**< HID communication error */
    HSC_RESULT_INVALID_PARAM  = -6, /**< Invalid parameter */
} hsc_result_t;

/* ============================================================================
 * Capabilities (matches C++ enum)
 * ============================================================================ */

typedef enum {
    HSC_CAP_SIDETONE                       = 0,
    HSC_CAP_BATTERY_STATUS                 = 1,
    HSC_CAP_NOTIFICATION_SOUND             = 2,
    HSC_CAP_LIGHTS                         = 3,
    HSC_CAP_INACTIVE_TIME                  = 4,
    HSC_CAP_CHATMIX_STATUS                 = 5,
    HSC_CAP_VOICE_PROMPTS                  = 6,
    HSC_CAP_ROTATE_TO_MUTE                 = 7,
    HSC_CAP_EQUALIZER_PRESET               = 8,
    HSC_CAP_EQUALIZER                      = 9,
    HSC_CAP_PARAMETRIC_EQUALIZER           = 10,
    HSC_CAP_MICROPHONE_MUTE_LED_BRIGHTNESS = 11,
    HSC_CAP_MICROPHONE_VOLUME              = 12,
    HSC_CAP_VOLUME_LIMITER                 = 13,
    HSC_CAP_BT_WHEN_POWERED_ON             = 14,
    HSC_CAP_BT_CALL_VOLUME                 = 15,
    HSC_CAP_NOISE_FILTER                   = 16,
    HSC_CAP_SIDETONE_STATUS                = 17,
    HSC_CAP_ANC                            = 18,
    HSC_CAP_ANC_STARTUP_MODE               = 19,
    HSC_CAP_ANC_BUTTON_MODES               = 20,
    HSC_CAP_MICROPHONE_ATTACHMENT_STATUS   = 21,
    HSC_CAP_MICROPHONE_MUTE_STATUS         = 22,
    HSC_CAP_HEADSET_VOLUME                 = 23,
    HSC_CAP_LIGHT_COLOR                    = 24,
    HSC_NUM_CAPABILITIES                   = 25,
} hsc_capability_t;

/* ============================================================================
 * Battery Status
 * ============================================================================ */

/* Matches the C++ battery_status enum, which hsc_get_battery() reports */
typedef enum {
    HSC_BATTERY_UNAVAILABLE = 0,
    HSC_BATTERY_CHARGING    = 1,
    HSC_BATTERY_AVAILABLE   = 2,
    HSC_BATTERY_ERROR       = 3,
    HSC_BATTERY_TIMEOUT     = 4,
} hsc_battery_status_t;

typedef struct {
    int level_percent; /**< Battery level 0-100, or -1 if unknown */
    hsc_battery_status_t status; /**< Battery status */
    int voltage_mv; /**< Voltage in mV, or -1 if not available */
    int time_to_full_min; /**< Minutes to full, or -1 if not available */
    int time_to_empty_min; /**< Minutes to empty, or -1 if not available */
} hsc_battery_t;

/* ============================================================================
 * Other Result Types
 * ============================================================================ */

typedef struct {
    uint8_t current_level;
    uint8_t min_level;
    uint8_t max_level;
} hsc_sidetone_t;

typedef struct {
    uint8_t current_level;
    uint8_t min_level;
    uint8_t max_level;
    uint8_t device_level;
    uint8_t device_min;
    uint8_t device_max;
    const char* level_name; /**< Name valid until next query or headset release; NULL if unavailable */
} hsc_sidetone_status_t;

typedef struct {
    int level; /**< Chat-mix level (0-128) */
    int game_volume_percent; /**< Game audio percentage */
    int chat_volume_percent; /**< Chat audio percentage */
} hsc_chatmix_t;

typedef struct {
    uint8_t minutes;
    uint8_t min_minutes;
    uint8_t max_minutes;
} hsc_inactive_time_t;

typedef struct {
    bool muted;
} hsc_mic_mute_status_t;

typedef struct {
    bool attached;
} hsc_mic_attachment_status_t;

typedef struct {
    bool off; /* Include off mode */
    bool anc; /* Include noise cancelling mode */
    bool ambient; /* Include ambient sound mode */
} hsc_anc_button_modes_t;

typedef struct {
    uint8_t volume; /**< Normalized volume level (0-128) */
    uint8_t min_volume; /**< Minimum supported level */
    uint8_t max_volume; /**< Maximum supported level */
    uint8_t device_volume; /**< Device's native level (e.g., 0-21 for the ASTRO A50) */
    uint8_t device_min; /**< Device's native minimum */
    uint8_t device_max; /**< Device's native maximum */
} hsc_headset_volume_t;

/* Band layout of the custom equalizer, see hsc_get_equalizer_info() */
typedef struct {
    int bands_count; /**< Number of bands hsc_set_equalizer() expects */
    int bands_baseline; /**< Band value that leaves the sound unchanged */
    float bands_step; /**< Smallest change of a band value */
    int bands_min; /**< Lowest band value */
    int bands_max; /**< Highest band value */
} hsc_equalizer_info_t;

/* Parametric equalizer filter types (matches the C++ EqualizerFilterType) */
typedef enum {
    HSC_EQ_FILTER_LOW_SHELF  = 0,
    HSC_EQ_FILTER_LOW_PASS   = 1,
    HSC_EQ_FILTER_PEAKING    = 2,
    HSC_EQ_FILTER_HIGH_PASS  = 3,
    HSC_EQ_FILTER_HIGH_SHELF = 4,
    HSC_EQ_FILTER_NOTCH      = 5,
} hsc_eq_filter_type_t;

/* Ranges of the parametric equalizer, see hsc_get_parametric_equalizer_info() */
typedef struct {
    int bands_count; /**< Maximum number of bands */
    float gain_base; /**< Gain that leaves the sound unchanged, in dB */
    float gain_step; /**< Smallest gain change, in dB */
    float gain_min; /**< Lowest gain, in dB */
    float gain_max; /**< Highest gain, in dB */
    float q_factor_min; /**< Lowest Q factor */
    float q_factor_max; /**< Highest Q factor */
    int freq_min; /**< Lowest frequency, in Hz */
    int freq_max; /**< Highest frequency, in Hz */
    int filter_types; /**< Supported types: bit (1 << type) for each hsc_eq_filter_type_t */
} hsc_parametric_equalizer_info_t;

/* One band of a parametric equalizer, see hsc_set_parametric_equalizer() */
typedef struct {
    float frequency; /**< Frequency in Hz */
    float gain; /**< Gain in dB */
    float q_factor; /**< Q factor */
    hsc_eq_filter_type_t type; /**< Filter type */
} hsc_parametric_band_t;

/* ============================================================================
 * Discovery Functions
 * ============================================================================ */

/**
 * @brief Discover connected headsets
 *
 * Allocates an array of headset handles. Caller must free with hsc_free_headsets().
 *
 * @param[out] headsets Pointer to receive array of headset handles
 * @return Number of headsets found, or negative error code
 */
HSC_API int hsc_discover(hsc_headset_t** headsets);

/**
 * @brief Free headset array returned by hsc_discover()
 *
 * @param headsets Array of headset handles
 * @param count Number of headsets in array
 */
HSC_API void hsc_free_headsets(hsc_headset_t* headsets, int count);

/**
 * @brief Get library version string
 *
 * @return Version string (do not free)
 */
HSC_API const char* hsc_version(void);

/**
 * @brief Get number of supported device types
 *
 * @return Number of device types the library supports
 */
HSC_API int hsc_supported_device_count(void);

/**
 * @brief Get name of supported device by index
 *
 * @param index Device index (0 to hsc_supported_device_count()-1)
 * @return Device name (do not free), or NULL if index out of range
 */
HSC_API const char* hsc_supported_device_name(int index);

/* ============================================================================
 * Headset Information
 * ============================================================================ */

/**
 * @brief Get headset name
 *
 * @param headset Headset handle
 * @return Device name (do not free)
 */
HSC_API const char* hsc_get_name(hsc_headset_t headset);

/**
 * @brief Get USB vendor ID
 *
 * @param headset Headset handle
 * @return Vendor ID
 */
HSC_API uint16_t hsc_get_vendor_id(hsc_headset_t headset);

/**
 * @brief Get USB vendor name
 *
 * @param headset Headset handle
 * @return Vendor name (do not free), or NULL if unavailable
 */
HSC_API const char* hsc_get_vendor_name(hsc_headset_t headset);

/**
 * @brief Get USB product ID
 *
 * @param headset Headset handle
 * @return Product ID
 */
HSC_API uint16_t hsc_get_product_id(hsc_headset_t headset);

/**
 * @brief Get product name
 *
 * Starts as the USB product string. The first call that opens the device lets
 * it refine the name, e.g. a dongle reporting the headset paired to it, so call
 * this again after a query such as hsc_get_battery() to get the refined name.
 *
 * @param headset Headset handle
 * @return Product name (do not free), or NULL if unavailable. Valid until the
 *         headset is freed; a pointer returned earlier keeps the USB string.
 */
HSC_API const char* hsc_get_product_name(hsc_headset_t headset);

/**
 * @brief Check if headset supports a capability
 *
 * @param headset Headset handle
 * @param cap Capability to check
 * @return true if supported, false otherwise
 */
HSC_API bool hsc_supports(hsc_headset_t headset, hsc_capability_t cap);

/**
 * @brief Get capabilities bitmask
 *
 * @param headset Headset handle
 * @return Bitmask of supported capabilities
 */
HSC_API int hsc_get_capabilities(hsc_headset_t headset);

/**
 * @brief Get the bitmask of capabilities that can also be read back
 *
 * Uses the same bits as hsc_get_capabilities(). For example, if
 * HSC_CAP_HEADSET_VOLUME is set, hsc_get_headset_volume() is available.
 *
 * @param headset Headset handle
 * @return Bitmask of readable capabilities
 */
HSC_API int hsc_get_readable_capabilities(hsc_headset_t headset);

/* ============================================================================
 * Battery & Status
 * ============================================================================ */

/**
 * @brief Get battery status
 *
 * @param headset Headset handle
 * @param[out] battery Battery info structure to fill
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_battery(hsc_headset_t headset, hsc_battery_t* battery);

/**
 * @brief Get chat-mix level
 *
 * @param headset Headset handle
 * @param[out] chatmix Chat-mix info structure to fill
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_chatmix(hsc_headset_t headset, hsc_chatmix_t* chatmix);

/**
 * @brief Get current sidetone level
 *
 * @param headset Headset handle
 * @param[out] sidetone Sidetone info structure to fill
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_sidetone(hsc_headset_t headset, hsc_sidetone_status_t* sidetone);

/**
 * @brief Get microphone mute status
 *
 * @param headset Headset handle
 * @param[out] status Microphone mute status to fill
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_mic_mute_status(hsc_headset_t headset, hsc_mic_mute_status_t* status);

/**
 * @brief Get whether the detachable boom mic is attached
 *
 * @param headset Headset handle
 * @param[out] status Microphone attachment status to fill
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_mic_attachment_status(hsc_headset_t headset, hsc_mic_attachment_status_t* status);

/* ============================================================================
 * Audio Controls
 * ============================================================================ */

/**
 * @brief Set sidetone level
 *
 * @param headset Headset handle
 * @param level Sidetone level (0-128, 0 = off)
 * @param[out] result Optional result info (can be NULL)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_sidetone(hsc_headset_t headset, uint8_t level, hsc_sidetone_t* result);

/**
 * @brief Set volume limiter
 *
 * @param headset Headset handle
 * @param enabled true to enable, false to disable
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_volume_limiter(hsc_headset_t headset, bool enabled);

/**
 * @brief Set the headset (output) volume
 *
 * Controls the volume of the headset hardware itself (the value the
 * on-device volume wheel changes), not the OS mixer volume.
 *
 * @param headset Headset handle
 * @param volume Volume level (0-128)
 * @param[out] result Optional result info (can be NULL)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_headset_volume(hsc_headset_t headset, uint8_t volume, hsc_headset_volume_t* result);

/**
 * @brief Read the headset (output) volume
 *
 * Only available when HSC_CAP_HEADSET_VOLUME is set in
 * hsc_get_readable_capabilities().
 *
 * @param headset Headset handle
 * @param[out] volume Volume info
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_headset_volume(hsc_headset_t headset, hsc_headset_volume_t* volume);

/* ============================================================================
 * Equalizer
 * ============================================================================ */

/**
 * @brief Set equalizer preset
 *
 * @param headset Headset handle
 * @param preset Preset ID
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_equalizer_preset(hsc_headset_t headset, uint8_t preset);

/**
 * @brief Set custom equalizer curve
 *
 * @param headset Headset handle
 * @param bands Array of band values
 * @param num_bands Number of bands in array
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_equalizer(hsc_headset_t headset, const float* bands, int num_bands);

/**
 * @brief Get the band layout of the custom equalizer
 *
 * Reads no HID data. Some devices learn their layout from the headset and can
 * only report it after an equalizer command on the same device (the Logitech
 * PRO X 2 does); until then this returns HSC_RESULT_NOT_SUPPORTED.
 *
 * @param headset Headset handle
 * @param[out] info Band layout
 * @return HSC_RESULT_OK on success, HSC_RESULT_NOT_SUPPORTED if the device
 *         doesn't describe its equalizer, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_equalizer_info(hsc_headset_t headset, hsc_equalizer_info_t* info);

/**
 * @brief Get the ranges of the parametric equalizer
 *
 * Reads no HID data.
 *
 * @param headset Headset handle
 * @param[out] info Parametric equalizer ranges
 * @return HSC_RESULT_OK on success, HSC_RESULT_NOT_SUPPORTED if the device
 *         doesn't describe its parametric equalizer, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_parametric_equalizer_info(
    hsc_headset_t headset,
    hsc_parametric_equalizer_info_t* info);

/**
 * @brief Set parametric equalizer bands
 *
 * @param headset Headset handle
 * @param bands Array of bands
 * @param num_bands Number of bands in array
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_parametric_equalizer(
    hsc_headset_t headset,
    const hsc_parametric_band_t* bands,
    int num_bands);

/**
 * @brief Get number of equalizer presets
 *
 * @param headset Headset handle
 * @return Number of presets, or 0 if not supported
 */
HSC_API int hsc_get_equalizer_presets_count(hsc_headset_t headset);

/**
 * @brief Get equalizer preset name
 *
 * @param headset Headset handle
 * @param preset Preset index
 * @return Preset name (do not free), or NULL if unavailable
 */
HSC_API const char* hsc_get_equalizer_preset_name(hsc_headset_t headset, int preset);

/**
 * @brief Get equalizer preset band count
 *
 * @param headset Headset handle
 * @param preset Preset index
 * @return Number of bands in the preset, or 0 if unavailable
 */
HSC_API int hsc_get_equalizer_preset_band_count(hsc_headset_t headset, int preset);

/**
 * @brief Copy equalizer preset bands into caller-provided buffer
 *
 * @param headset Headset handle
 * @param preset Preset index
 * @param[out] bands Buffer receiving band values
 * @param num_bands Number of elements available in bands
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_get_equalizer_preset_bands(
    hsc_headset_t headset,
    int preset,
    float* bands,
    int num_bands);

/* ============================================================================
 * Microphone
 * ============================================================================ */

/**
 * @brief Set microphone volume
 *
 * @param headset Headset handle
 * @param volume Volume level (0-128)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_mic_volume(hsc_headset_t headset, uint8_t volume);

/**
 * @brief Set microphone mute LED brightness
 *
 * @param headset Headset handle
 * @param brightness Brightness level (0-3)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_mic_mute_led_brightness(hsc_headset_t headset, uint8_t brightness);

/**
 * @brief Set microphone noise filter level
 *
 * @param headset Headset handle
 * @param level 0 = off, 1 = low, 2 = high
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_noise_filter(hsc_headset_t headset, uint8_t level);

/**
 * @brief Set rotate-to-mute feature
 *
 * @param headset Headset handle
 * @param enabled true to enable, false to disable
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_rotate_to_mute(hsc_headset_t headset, bool enabled);

/* ============================================================================
 * Lights & Audio Cues
 * ============================================================================ */

/**
 * @brief Set lights on/off
 *
 * @param headset Headset handle
 * @param enabled true for on, false for off
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_lights(hsc_headset_t headset, bool enabled);

/**
 * @brief Set the color of the lights, which also turns them on
 *
 * Applies to every LED zone. Black (0, 0, 0) is a valid color and may switch
 * the lights off on some devices.
 *
 * @param headset Headset handle
 * @param r Red component (0-255)
 * @param g Green component (0-255)
 * @param b Blue component (0-255)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_light_color(hsc_headset_t headset, uint8_t r, uint8_t g, uint8_t b);

/**
 * @brief Set voice prompts on/off
 *
 * @param headset Headset handle
 * @param enabled true to enable, false to disable
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_voice_prompts(hsc_headset_t headset, bool enabled);

/**
 * @brief Play notification sound
 *
 * @param headset Headset handle
 * @param sound_id Sound ID to play
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_play_notification_sound(hsc_headset_t headset, uint8_t sound_id);

/* ============================================================================
 * Power & Bluetooth
 * ============================================================================ */

/**
 * @brief Set inactive time (auto power-off)
 *
 * @param headset Headset handle
 * @param minutes Minutes until power-off (0 = disabled)
 * @param[out] result Optional result info (can be NULL)
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_inactive_time(hsc_headset_t headset, uint8_t minutes, hsc_inactive_time_t* result);

/**
 * @brief Set Bluetooth when powered on
 *
 * @param headset Headset handle
 * @param enabled true to enable, false to disable
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_bluetooth_when_powered_on(hsc_headset_t headset, bool enabled);

/**
 * @brief Set Bluetooth call volume
 *
 * @param headset Headset handle
 * @param volume Volume level
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_bluetooth_call_volume(hsc_headset_t headset, uint8_t volume);

/**
 * @brief Set active noise cancellation mode
 *
 * @param headset Headset handle
 * @param mode 0 = off, 1 = noise cancelling, 2 = ambient sound
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_anc(hsc_headset_t headset, uint8_t mode);

/**
 * @brief Set ANC mode used at power-on
 *
 * @param headset Headset handle
 * @param mode 0 = off, 1 = noise cancelling, 2 = ambient sound, 3 = mode at power off
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_anc_startup_mode(hsc_headset_t headset, uint8_t mode);

/**
 * @brief Set ANC modes the headset's ANC button cycles through
 *
 * At least one mode must be enabled.
 *
 * @param headset Headset handle
 * @param modes Modes the ANC button cycles through
 * @return HSC_RESULT_OK on success, negative error code on failure
 */
HSC_API hsc_result_t hsc_set_anc_button_modes(hsc_headset_t headset, const hsc_anc_button_modes_t* modes);

/* ============================================================================
 * Test Device Mode
 * ============================================================================ */

/**
 * @brief Enable or disable test device mode
 *
 * When enabled, hsc_discover() will include the HeadsetControl Test device
 * (0xF00B:0xA00C) even when no physical device is connected.
 *
 * @param enabled true to enable, false to disable
 */
HSC_API void hsc_enable_test_device(bool enabled);

/**
 * @brief Check if test device mode is enabled
 *
 * @return true if test device mode is enabled
 */
HSC_API bool hsc_is_test_device_enabled(void);

/* ============================================================================
 * Configuration
 * ============================================================================ */

/**
 * @brief Set the HID device timeout
 *
 * Controls how long HID read operations wait for a response.
 * Default is 5000ms (5 seconds).
 *
 * @param timeout_ms Timeout in milliseconds
 */
HSC_API void hsc_set_device_timeout(int timeout_ms);

/**
 * @brief Get the current HID device timeout
 *
 * @return Timeout in milliseconds
 */
HSC_API int hsc_get_device_timeout(void);

/**
 * @brief Set the test profile for the test device
 *
 * Controls the behavior of the HeadsetControl Test device.
 * Only useful when test device mode is enabled.
 *
 * Profiles:
 * - 0: Normal operation (default; 42%, 3650 mV, ~302 min to empty)
 * - 1: HID errors for battery and most get/set calls
 * - 2: Charging (50%, ~60 min to full)
 * - 3: Battery without extended info (64%, no optional fields)
 * - 4: Battery unavailable (device offline error)
 * - 5: Timeout errors
 * - 6: Full battery (100%, 720 min to empty); headset volume settable only
 * - 7: Low battery (10%, 72 min to empty)
 * - 8: Charging, level not yet reported (level -1, BATTERY_CHARGING)
 * - 9: Reserved (default fallback: 42%, available)
 * - 10: Limited capabilities (sidetone, lights, battery only; nothing readable)
 *
 * @param profile Profile number
 */
HSC_API void hsc_set_test_profile(int profile);

/**
 * @brief Get the current test profile
 *
 * @return Current test profile number
 */
HSC_API int hsc_get_test_profile(void);

#ifdef __cplusplus
}
#endif

#endif /* HEADSETCONTROL_C_H */
