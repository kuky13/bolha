#include "headsetcontrol_c.h"
#include "headsetcontrol.hpp"

#include <cstring>
#include <string>
#include <vector>

// ============================================================================
// Internal State
// ============================================================================

namespace {

// Store discovered headsets and their string names
struct HeadsetWrapper {
    headsetcontrol::Headset headset;
    std::string name_str; // Persistent storage for C string
    std::string vendor_name_str;
    std::string product_name_str;
    std::string refined_product_name_str; // Assigned once, so earlier pointers stay valid
    std::optional<EqualizerPresets> equalizer_presets_cache;
    std::string sidetone_level_name_cache;

    explicit HeadsetWrapper(headsetcontrol::Headset&& h)
        : headset(std::move(h))
        , name_str(headset.name())
        , vendor_name_str(headset.vendorName())
        , product_name_str(headset.productName())
    {
    }
};

// Cache for supported device names (lazily populated on first access)
// NOLINTBEGIN(cppcoreguidelines-avoid-non-const-global-variables)
std::vector<std::string> g_supported_device_names;
bool g_supported_devices_cached = false;
// NOLINTEND(cppcoreguidelines-avoid-non-const-global-variables)

void ensureSupportedDevicesCached()
{
    if (!g_supported_devices_cached) {
        g_supported_device_names.clear();
        for (auto name : headsetcontrol::supportedDevices()) {
            g_supported_device_names.emplace_back(name);
        }
        g_supported_devices_cached = true;
    }
}

// Convert C++ error to C error code
hsc_result_t toErrorCode(const headsetcontrol::DeviceError& error)
{
    switch (error.code) {
    case headsetcontrol::DeviceError::Code::Success:
        return HSC_RESULT_OK;
    case headsetcontrol::DeviceError::Code::Timeout:
        return HSC_RESULT_TIMEOUT;
    case headsetcontrol::DeviceError::Code::DeviceOffline:
        return HSC_RESULT_DEVICE_OFFLINE;
    case headsetcontrol::DeviceError::Code::NotSupported:
        return HSC_RESULT_NOT_SUPPORTED;
    case headsetcontrol::DeviceError::Code::InvalidParameter:
        return HSC_RESULT_INVALID_PARAM;
    case headsetcontrol::DeviceError::Code::HIDError:
        return HSC_RESULT_HID_ERROR;
    default:
        return HSC_RESULT_ERROR;
    }
}

// Version string storage (lazily initialized)
// NOLINTNEXTLINE(cppcoreguidelines-avoid-non-const-global-variables)
std::string g_version_str;

const EqualizerPresets* getCachedEqualizerPresets(HeadsetWrapper& wrapper)
{
    if (!wrapper.equalizer_presets_cache.has_value()) {
        wrapper.equalizer_presets_cache = wrapper.headset.getEqualizerPresets();
    }

    if (!wrapper.equalizer_presets_cache.has_value()) {
        return nullptr;
    }

    return &(*wrapper.equalizer_presets_cache);
}

void copySidetoneStatus(const headsetcontrol::SidetoneResult& source,
    hsc_sidetone_status_t& destination, std::string& level_name_cache)
{
    destination.current_level = source.current_level;
    destination.min_level     = source.min_level;
    destination.max_level     = source.max_level;
    destination.device_level  = source.device_level;
    destination.device_min    = source.device_min;
    destination.device_max    = source.device_max;
    level_name_cache          = source.level_name.value_or("");
    destination.level_name    = level_name_cache.empty() ? nullptr : level_name_cache.c_str();
}

void copyHeadsetVolume(const headsetcontrol::HeadsetVolumeResult& source, hsc_headset_volume_t& target)
{
    target.volume        = source.volume;
    target.min_volume    = source.min_volume;
    target.max_volume    = source.max_volume;
    target.device_volume = source.device_volume;
    target.device_min    = source.device_min;
    target.device_max    = source.device_max;
}

} // namespace

// ============================================================================
// Discovery Functions
// ============================================================================

extern "C" {

int hsc_discover(hsc_headset_t** headsets)
{
    if (!headsets) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto discovered = headsetcontrol::discover();

    if (discovered.empty()) {
        *headsets = nullptr;
        return 0;
    }

    // Allocate array of handles
    *headsets = static_cast<hsc_headset_t*>(
        malloc(discovered.size() * sizeof(hsc_headset_t)));

    if (!*headsets) {
        return HSC_RESULT_ERROR;
    }

    // Create wrappers for each headset
    // NOLINTBEGIN(cppcoreguidelines-owning-memory)
    // Raw new/delete required: C API where caller manages lifetime via hsc_free_headsets()
    for (size_t i = 0; i < discovered.size(); i++) {
        (*headsets)[i] = new HeadsetWrapper(std::move(discovered[i]));
    }
    // NOLINTEND(cppcoreguidelines-owning-memory)

    return static_cast<int>(discovered.size());
}

void hsc_free_headsets(hsc_headset_t* headsets, int count)
{
    if (!headsets) {
        return;
    }

    // NOLINTBEGIN(cppcoreguidelines-owning-memory)
    // Raw delete required: C API paired with hsc_discover() allocation
    for (int i = 0; i < count; i++) {
        delete static_cast<HeadsetWrapper*>(headsets[i]);
    }

    // NOLINTNEXTLINE(bugprone-multi-level-implicit-pointer-conversion)
    free(headsets);
    // NOLINTEND(cppcoreguidelines-owning-memory)
}

const char* hsc_version(void)
{
    if (g_version_str.empty()) {
        g_version_str = std::string(headsetcontrol::version());
    }
    return g_version_str.c_str();
}

int hsc_supported_device_count(void)
{
    ensureSupportedDevicesCached();
    return static_cast<int>(g_supported_device_names.size());
}

const char* hsc_supported_device_name(int index)
{
    ensureSupportedDevicesCached();
    if (index < 0 || index >= static_cast<int>(g_supported_device_names.size())) {
        return nullptr;
    }
    return g_supported_device_names[index].c_str();
}

// ============================================================================
// Headset Information
// ============================================================================

const char* hsc_get_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }
    return static_cast<HeadsetWrapper*>(headset)->name_str.c_str();
}

uint16_t hsc_get_vendor_id(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.vendorId();
}

const char* hsc_get_vendor_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }

    const auto& vendor_name = static_cast<HeadsetWrapper*>(headset)->vendor_name_str;
    return vendor_name.empty() ? nullptr : vendor_name.c_str();
}

uint16_t hsc_get_product_id(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.productId();
}

const char* hsc_get_product_name(hsc_headset_t headset)
{
    if (!headset) {
        return nullptr;
    }

    auto* wrapper = static_cast<HeadsetWrapper*>(headset);

    // The device may have refined the name since the wrapper was created. It is
    // refined at most once, so the copy never has to be reassigned.
    if (wrapper->refined_product_name_str.empty()
        && wrapper->headset.productName() != wrapper->product_name_str) {
        wrapper->refined_product_name_str = wrapper->headset.productName();
    }

    const auto& product_name = wrapper->refined_product_name_str.empty()
        ? wrapper->product_name_str
        : wrapper->refined_product_name_str;
    return product_name.empty() ? nullptr : product_name.c_str();
}

// hsc_capability_t mirrors the capabilities enum by value, and hsc_supports()
// casts straight between them, so the X-macro generates one check per capability
// rather than leaving the C header to be kept in step by hand.
#define X(cap, str, short_char) static_assert(HSC_##cap == static_cast<int>(cap));
CAPABILITIES_XLIST
#undef X
static_assert(HSC_NUM_CAPABILITIES == static_cast<int>(NUM_CAPABILITIES));

bool hsc_supports(hsc_headset_t headset, hsc_capability_t cap)
{
    if (!headset) {
        return false;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.supports(
        static_cast<capabilities>(cap));
}

int hsc_get_capabilities(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.capabilitiesMask();
}

int hsc_get_readable_capabilities(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.readableCapabilitiesMask();
}

// ============================================================================
// Battery & Status
// ============================================================================

// hsc_get_battery() passes the C++ status through unchanged, so the C values
// have to stay in step with it.
static_assert(HSC_BATTERY_UNAVAILABLE == static_cast<int>(BATTERY_UNAVAILABLE));
static_assert(HSC_BATTERY_CHARGING == static_cast<int>(BATTERY_CHARGING));
static_assert(HSC_BATTERY_AVAILABLE == static_cast<int>(BATTERY_AVAILABLE));
static_assert(HSC_BATTERY_ERROR == static_cast<int>(BATTERY_HIDERROR));
static_assert(HSC_BATTERY_TIMEOUT == static_cast<int>(BATTERY_TIMEOUT));

hsc_result_t hsc_get_battery(hsc_headset_t headset, hsc_battery_t* battery)
{
    if (!headset || !battery) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getBattery();

    if (!result) {
        return toErrorCode(result.error());
    }

    battery->level_percent     = result->level_percent;
    battery->status            = static_cast<hsc_battery_status_t>(result->status);
    battery->voltage_mv        = result->voltage_mv.value_or(-1);
    battery->time_to_full_min  = result->time_to_full_min.value_or(-1);
    battery->time_to_empty_min = result->time_to_empty_min.value_or(-1);

    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_chatmix(hsc_headset_t headset, hsc_chatmix_t* chatmix)
{
    if (!headset || !chatmix) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getChatmix();

    if (!result) {
        return toErrorCode(result.error());
    }

    chatmix->level               = result->level;
    chatmix->game_volume_percent = result->game_volume_percent;
    chatmix->chat_volume_percent = result->chat_volume_percent;

    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_sidetone(hsc_headset_t headset, hsc_sidetone_status_t* sidetone)
{
    if (!headset || !sidetone) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto& wrapper = *static_cast<HeadsetWrapper*>(headset);
    auto result   = wrapper.headset.getSidetone();
    if (!result) {
        return toErrorCode(result.error());
    }

    copySidetoneStatus(*result, *sidetone, wrapper.sidetone_level_name_cache);
    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_mic_mute_status(hsc_headset_t headset, hsc_mic_mute_status_t* status)
{
    if (!headset || !status) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getMicMuteStatus();
    if (!result) {
        return toErrorCode(result.error());
    }

    status->muted = result->muted;
    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_mic_attachment_status(hsc_headset_t headset, hsc_mic_attachment_status_t* status)
{
    if (!headset || !status) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getMicAttachmentStatus();
    if (!result) {
        return toErrorCode(result.error());
    }

    status->attached = result->attached;
    return HSC_RESULT_OK;
}

// ============================================================================
// Audio Controls
// ============================================================================

hsc_result_t hsc_set_sidetone(hsc_headset_t headset, uint8_t level, hsc_sidetone_t* result_out)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setSidetone(level);

    if (!result) {
        return toErrorCode(result.error());
    }

    if (result_out) {
        result_out->current_level = result->current_level;
        result_out->min_level     = result->min_level;
        result_out->max_level     = result->max_level;
    }

    return HSC_RESULT_OK;
}

hsc_result_t hsc_set_volume_limiter(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setVolumeLimiter(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_headset_volume(hsc_headset_t headset, uint8_t volume, hsc_headset_volume_t* result_out)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setHeadsetVolume(volume);

    if (!result) {
        return toErrorCode(result.error());
    }

    if (result_out) {
        copyHeadsetVolume(*result, *result_out);
    }

    return HSC_RESULT_OK;
}

hsc_result_t hsc_get_headset_volume(hsc_headset_t headset, hsc_headset_volume_t* volume)
{
    if (!headset || !volume) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.getHeadsetVolume();

    if (!result) {
        return toErrorCode(result.error());
    }

    copyHeadsetVolume(*result, *volume);
    return HSC_RESULT_OK;
}

// ============================================================================
// Equalizer
// ============================================================================

hsc_result_t hsc_set_equalizer_preset(hsc_headset_t headset, uint8_t preset)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setEqualizerPreset(preset);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_equalizer(hsc_headset_t headset, const float* bands, int num_bands)
{
    if (!headset || !bands || num_bands <= 0) {
        return HSC_RESULT_INVALID_PARAM;
    }

    EqualizerSettings settings({ bands, bands + num_bands });
    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setEqualizer(settings);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_get_equalizer_info(hsc_headset_t headset, hsc_equalizer_info_t* info)
{
    if (!headset || !info) {
        return HSC_RESULT_INVALID_PARAM;
    }

    const auto& h = static_cast<HeadsetWrapper*>(headset)->headset;
    if (!h.supports(CAP_EQUALIZER)) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    auto eq_info = h.getEqualizerInfo();
    if (!eq_info) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    info->bands_count    = eq_info->bands_count;
    info->bands_baseline = eq_info->bands_baseline;
    info->bands_step     = eq_info->bands_step;
    info->bands_min      = eq_info->bands_min;
    info->bands_max      = eq_info->bands_max;
    return HSC_RESULT_OK;
}

// Filter types cross the boundary as their numeric value, in both directions.
static_assert(HSC_EQ_FILTER_LOW_SHELF == static_cast<int>(EqualizerFilterType::LowShelf));
static_assert(HSC_EQ_FILTER_LOW_PASS == static_cast<int>(EqualizerFilterType::LowPass));
static_assert(HSC_EQ_FILTER_PEAKING == static_cast<int>(EqualizerFilterType::Peaking));
static_assert(HSC_EQ_FILTER_HIGH_PASS == static_cast<int>(EqualizerFilterType::HighPass));
static_assert(HSC_EQ_FILTER_HIGH_SHELF == static_cast<int>(EqualizerFilterType::HighShelf));
static_assert(HSC_EQ_FILTER_NOTCH == static_cast<int>(EqualizerFilterType::Notch));
static_assert(HSC_EQ_FILTER_NOTCH + 1 == NUM_EQ_FILTER_TYPES);

hsc_result_t hsc_get_parametric_equalizer_info(hsc_headset_t headset, hsc_parametric_equalizer_info_t* info)
{
    if (!headset || !info) {
        return HSC_RESULT_INVALID_PARAM;
    }

    const auto& h = static_cast<HeadsetWrapper*>(headset)->headset;
    if (!h.supports(CAP_PARAMETRIC_EQUALIZER)) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    auto peq_info = h.getParametricEqualizerInfo();
    if (!peq_info) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    info->bands_count  = peq_info->bands_count;
    info->gain_base    = peq_info->gain_base;
    info->gain_step    = peq_info->gain_step;
    info->gain_min     = peq_info->gain_min;
    info->gain_max     = peq_info->gain_max;
    info->q_factor_min = peq_info->q_factor_min;
    info->q_factor_max = peq_info->q_factor_max;
    info->freq_min     = peq_info->freq_min;
    info->freq_max     = peq_info->freq_max;
    info->filter_types = peq_info->filter_types;
    return HSC_RESULT_OK;
}

hsc_result_t hsc_set_parametric_equalizer(hsc_headset_t headset, const hsc_parametric_band_t* bands, int num_bands)
{
    if (!headset || !bands || num_bands <= 0) {
        return HSC_RESULT_INVALID_PARAM;
    }

    ParametricEqualizerSettings settings;
    settings.bands.reserve(static_cast<size_t>(num_bands));
    for (int i = 0; i < num_bands; ++i) {
        const auto& band = bands[i];
        const int type   = band.type;
        if (type < 0 || type >= NUM_EQ_FILTER_TYPES) {
            return HSC_RESULT_INVALID_PARAM;
        }
        settings.bands.push_back({ .frequency = band.frequency,
            .gain                             = band.gain,
            .q_factor                         = band.q_factor,
            .type                             = static_cast<EqualizerFilterType>(band.type) });
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setParametricEqualizer(settings);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

int hsc_get_equalizer_presets_count(hsc_headset_t headset)
{
    if (!headset) {
        return 0;
    }
    return static_cast<HeadsetWrapper*>(headset)->headset.getEqualizerPresetsCount();
}

const char* hsc_get_equalizer_preset_name(hsc_headset_t headset, int preset)
{
    if (!headset || preset < 0) {
        return nullptr;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets || preset >= static_cast<int>(presets->presets.size())) {
        return nullptr;
    }

    return presets->presets[static_cast<size_t>(preset)].name.c_str();
}

int hsc_get_equalizer_preset_band_count(hsc_headset_t headset, int preset)
{
    if (!headset || preset < 0) {
        return 0;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets || preset >= static_cast<int>(presets->presets.size())) {
        return 0;
    }

    return static_cast<int>(presets->presets[static_cast<size_t>(preset)].values.size());
}

hsc_result_t hsc_get_equalizer_preset_bands(
    hsc_headset_t headset,
    int preset,
    float* bands,
    int num_bands)
{
    if (!headset || !bands || preset < 0 || num_bands <= 0) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto& wrapper       = *static_cast<HeadsetWrapper*>(headset);
    const auto* presets = getCachedEqualizerPresets(wrapper);
    if (!presets) {
        return HSC_RESULT_NOT_SUPPORTED;
    }

    if (preset >= static_cast<int>(presets->presets.size())) {
        return HSC_RESULT_INVALID_PARAM;
    }

    const auto& values = presets->presets[static_cast<size_t>(preset)].values;
    if (num_bands < static_cast<int>(values.size())) {
        return HSC_RESULT_INVALID_PARAM;
    }

    std::memcpy(bands, values.data(), values.size() * sizeof(float));
    return HSC_RESULT_OK;
}

// ============================================================================
// Microphone
// ============================================================================

hsc_result_t hsc_set_mic_volume(hsc_headset_t headset, uint8_t volume)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setMicVolume(volume);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_mic_mute_led_brightness(hsc_headset_t headset, uint8_t brightness)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setMicMuteLedBrightness(brightness);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_noise_filter(hsc_headset_t headset, uint8_t level)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setNoiseFilter(level);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_rotate_to_mute(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setRotateToMute(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Lights & Audio Cues
// ============================================================================

hsc_result_t hsc_set_lights(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setLights(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_light_color(hsc_headset_t headset, uint8_t r, uint8_t g, uint8_t b)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setLightColor(
        LightColorSettings { .r = r, .g = g, .b = b });
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_voice_prompts(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setVoicePrompts(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_play_notification_sound(hsc_headset_t headset, uint8_t sound_id)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.playNotificationSound(sound_id);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Power & Bluetooth
// ============================================================================

hsc_result_t hsc_set_inactive_time(hsc_headset_t headset, uint8_t minutes, hsc_inactive_time_t* result_out)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setInactiveTime(minutes);

    if (!result) {
        return toErrorCode(result.error());
    }

    if (result_out) {
        result_out->minutes     = result->minutes;
        result_out->min_minutes = result->min_minutes;
        result_out->max_minutes = result->max_minutes;
    }

    return HSC_RESULT_OK;
}

hsc_result_t hsc_set_bluetooth_when_powered_on(hsc_headset_t headset, bool enabled)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setBluetoothWhenPoweredOn(enabled);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_bluetooth_call_volume(hsc_headset_t headset, uint8_t volume)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setBluetoothCallVolume(volume);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_anc(hsc_headset_t headset, uint8_t mode)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setAnc(mode);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_anc_startup_mode(hsc_headset_t headset, uint8_t mode)
{
    if (!headset) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setAncStartupMode(mode);
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

hsc_result_t hsc_set_anc_button_modes(hsc_headset_t headset, const hsc_anc_button_modes_t* modes)
{
    if (!headset || !modes) {
        return HSC_RESULT_INVALID_PARAM;
    }

    auto result = static_cast<HeadsetWrapper*>(headset)->headset.setAncButtonModes(
        AncButtonModes { .off = modes->off, .anc = modes->anc, .ambient = modes->ambient });
    return result ? HSC_RESULT_OK : toErrorCode(result.error());
}

// ============================================================================
// Test Device Mode
// ============================================================================

void hsc_enable_test_device(bool enabled)
{
    headsetcontrol::enableTestDevice(enabled);
}

bool hsc_is_test_device_enabled(void)
{
    return headsetcontrol::isTestDeviceEnabled();
}

// ============================================================================
// Configuration
// ============================================================================

void hsc_set_device_timeout(int timeout_ms)
{
    headsetcontrol::setDeviceTimeout(timeout_ms);
}

int hsc_get_device_timeout(void)
{
    return headsetcontrol::getDeviceTimeout();
}

void hsc_set_test_profile(int profile)
{
    headsetcontrol::setTestProfile(profile);
}

int hsc_get_test_profile(void)
{
    return headsetcontrol::getTestProfile();
}

} // extern "C"
