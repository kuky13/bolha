# ------------------------------------------------------------------------------
# HeadsetControl Tests
# ------------------------------------------------------------------------------

set(TEST_SOURCES
    ${CMAKE_CURRENT_SOURCE_DIR}/test_runner.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_output_formats.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_cli_output.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_library_linkage.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_utilities.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_edge_cases.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_hid_interface.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_device_registry.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_string_escaping.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_library_api.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_protocols.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_steelseries_sidetone.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_hyperx_cloud_alpha_2_wireless.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_hyperx_cloud_alpha_s.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_sony_pulse_3d.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_sennheiser_gsp370.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_corsair_virtuoso.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_razer_blackshark_v2_pro_ps.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_mchose.cpp
    ${CMAKE_CURRENT_SOURCE_DIR}/test_fifine.cpp
)

# Export to parent scope
set(TEST_SOURCES ${TEST_SOURCES} PARENT_SCOPE)
