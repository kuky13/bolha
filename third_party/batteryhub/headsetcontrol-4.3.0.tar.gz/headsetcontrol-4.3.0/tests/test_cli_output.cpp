/**
 * @file test_cli_output.cpp
 * @brief CLI integration tests for output format validation
 *
 * These tests run the actual headsetcontrol binary with --test-device
 * and validate the output format.
 */

#include <array>
#include <cstdio>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>

// Platform-specific executable path
#ifdef _WIN32
#define HEADSETCONTROL_EXE ".\\headsetcontrol.exe"
#else
#define HEADSETCONTROL_EXE "./headsetcontrol"
#endif

namespace headsetcontrol::testing {

// ============================================================================
// Test Utilities
// ============================================================================

class TestFailure : public std::runtime_error {
public:
    explicit TestFailure(const std::string& msg)
        : std::runtime_error(msg)
    {
    }
};

#define ASSERT_TRUE(cond, msg)                                              \
    do {                                                                    \
        if (!(cond)) {                                                      \
            throw TestFailure(std::string("ASSERT_TRUE failed: ") + (msg)); \
        }                                                                   \
    } while (0)

#define ASSERT_CONTAINS(haystack, needle, msg)                 \
    do {                                                       \
        if ((haystack).find(needle) == std::string::npos) {    \
            std::ostringstream oss;                            \
            oss << "ASSERT_CONTAINS failed: " << (msg) << "\n" \
                << "  Looking for: " << (needle) << "\n"       \
                << "  In output (first 500 chars):\n"          \
                << (haystack).substr(0, 500);                  \
            throw TestFailure(oss.str());                      \
        }                                                      \
    } while (0)

#define ASSERT_NOT_CONTAINS(haystack, needle, msg)                 \
    do {                                                           \
        if ((haystack).find(needle) != std::string::npos) {        \
            std::ostringstream oss;                                \
            oss << "ASSERT_NOT_CONTAINS failed: " << (msg) << "\n" \
                << "  Found (shouldn't be there): " << (needle);   \
            throw TestFailure(oss.str());                          \
        }                                                          \
    } while (0)

// Execute a command and return its output
[[nodiscard]] std::string exec(const char* cmd)
{
    std::array<char, 4096> buffer;
    std::string result;
#ifdef _MSC_VER
    std::unique_ptr<FILE, int (*)(FILE*)> pipe(_popen(cmd, "r"), _pclose);
#else
    std::unique_ptr<FILE, int (*)(FILE*)> pipe(popen(cmd, "r"), pclose);
#endif
    if (!pipe) {
        throw std::runtime_error("popen() failed!");
    }
    while (fgets(buffer.data(), static_cast<int>(buffer.size()), pipe.get()) != nullptr) {
        result += buffer.data();
    }
    return result;
}

// ============================================================================
// JSON CLI Tests
// ============================================================================

void testCliJsonOutput()
{
    std::cout << "  Testing CLI JSON output with --test-device..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o json 2>&1");

    // Verify JSON structure
    ASSERT_CONTAINS(output, "{", "JSON should start with opening brace");
    ASSERT_CONTAINS(output, "}", "JSON should end with closing brace");

    // Verify required fields
    ASSERT_CONTAINS(output, "\"name\": \"HeadsetControl\"", "Should have name field");
    ASSERT_CONTAINS(output, "\"api_version\":", "Should have api_version");
    ASSERT_CONTAINS(output, "\"device_count\":", "Should have device_count");
    ASSERT_CONTAINS(output, "\"devices\": [", "Should have devices array");

    // Verify test device info
    ASSERT_CONTAINS(output, "\"device\": \"HeadsetControl Test device\"",
        "Should have test device name");
    ASSERT_CONTAINS(output, "\"id_vendor\": \"0xf00b\"", "Should have test vendor ID");
    ASSERT_CONTAINS(output, "\"id_product\": \"0xa00c\"", "Should have test product ID");

    // Verify battery info (test device returns battery)
    ASSERT_CONTAINS(output, "\"battery\":", "Should have battery object");
    ASSERT_CONTAINS(output, "\"level\":", "Should have battery level");
    ASSERT_CONTAINS(output, "\"status\":", "Should have battery status");

    // Verify capabilities
    ASSERT_CONTAINS(output, "\"capabilities\":", "Should have capabilities");
    ASSERT_CONTAINS(output, "CAP_BATTERY_STATUS", "Should have battery capability");
    ASSERT_CONTAINS(output, "CAP_SIDETONE", "Should have sidetone capability");

    std::cout << "    ✓ CLI JSON output is correct" << std::endl;
}

void testCliJsonValid()
{
    std::cout << "  Testing CLI JSON is parseable..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o json 2>&1");

    // Basic JSON validation: matching braces and brackets
    int braceCount   = 0;
    int bracketCount = 0;
    bool inString    = false;
    char prevChar    = '\0';

    for (char c : output) {
        if (c == '"' && prevChar != '\\') {
            inString = !inString;
        }
        if (!inString) {
            if (c == '{')
                braceCount++;
            if (c == '}')
                braceCount--;
            if (c == '[')
                bracketCount++;
            if (c == ']')
                bracketCount--;
        }
        prevChar = c;
    }

    ASSERT_TRUE(braceCount == 0, "JSON braces should be balanced");
    ASSERT_TRUE(bracketCount == 0, "JSON brackets should be balanced");

    std::cout << "    ✓ CLI JSON is structurally valid" << std::endl;
}

// ============================================================================
// YAML CLI Tests
// ============================================================================

void testCliYamlOutput()
{
    std::cout << "  Testing CLI YAML output with --test-device..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o yaml 2>&1");

    // Verify YAML structure
    ASSERT_CONTAINS(output, "---", "YAML should start with document marker");

    // Verify required fields
    ASSERT_CONTAINS(output, "name: \"HeadsetControl\"", "Should have name field");
    ASSERT_CONTAINS(output, "api_version:", "Should have api_version");
    ASSERT_CONTAINS(output, "device_count:", "Should have device_count");
    ASSERT_CONTAINS(output, "devices:", "Should have devices list");

    // Verify test device
    ASSERT_CONTAINS(output, "- status:", "Should have device with status");
    ASSERT_CONTAINS(output, "HeadsetControl Test device", "Should have test device name");

    // Verify battery
    ASSERT_CONTAINS(output, "battery:", "Should have battery section");
    ASSERT_CONTAINS(output, "level:", "Should have battery level");

    std::cout << "    ✓ CLI YAML output is correct" << std::endl;
}

void testCliYamlIndentation()
{
    std::cout << "  Testing CLI YAML indentation..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o yaml 2>&1");

    // Check that device entries use proper YAML list format
    // "- status:" should be followed by "  device:" (aligned)
    size_t statusPos = output.find("- status:");
    ASSERT_TRUE(statusPos != std::string::npos, "Should find '- status:'");

    // Find the line with "device:"
    size_t devicePos = output.find("device:", statusPos);
    ASSERT_TRUE(devicePos != std::string::npos, "Should find 'device:' after status");

    // Get the line containing "device:"
    size_t lineStart       = output.rfind('\n', devicePos) + 1;
    std::string deviceLine = output.substr(lineStart, devicePos - lineStart + 7);

    // Count leading spaces
    size_t leadingSpaces = 0;
    for (char c : deviceLine) {
        if (c == ' ')
            leadingSpaces++;
        else
            break;
    }

    // Get status line position
    size_t statusLineStart = output.rfind('\n', statusPos);
    if (statusLineStart == std::string::npos)
        statusLineStart = 0;
    else
        statusLineStart++;

    size_t statusLeadingSpaces = 0;
    for (size_t i = statusLineStart; i < statusPos && output[i] == ' '; i++) {
        statusLeadingSpaces++;
    }

    // "device:" should be 2 more spaces than "- status:" (to align with "status")
    // status is at position: statusLeadingSpaces + 2 (for "- ")
    // device should be at: statusLeadingSpaces + 2
    size_t expectedDeviceIndent = statusLeadingSpaces + 2;

    ASSERT_TRUE(leadingSpaces == expectedDeviceIndent,
        "device should align with status (accounting for '- ')");

    std::cout << "    ✓ CLI YAML indentation is correct" << std::endl;
}

// ============================================================================
// ENV CLI Tests
// ============================================================================

void testCliEnvOutput()
{
    std::cout << "  Testing CLI ENV output with --test-device..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o env 2>&1");

    // Verify ENV format (KEY=value or KEY="value")
    ASSERT_CONTAINS(output, "HEADSETCONTROL_NAME=", "Should have name variable");
    ASSERT_CONTAINS(output, "HEADSETCONTROL_VERSION=", "Should have version variable");
    ASSERT_CONTAINS(output, "DEVICE_COUNT=", "Should have device count");
    ASSERT_CONTAINS(output, "DEVICE_0=", "Should have device 0");

    // Verify test device info
    ASSERT_CONTAINS(output, "HeadsetControl Test device", "Should have test device name");

    // Verify battery info
    ASSERT_CONTAINS(output, "BATTERY_STATUS=", "Should have battery status");
    ASSERT_CONTAINS(output, "BATTERY_LEVEL=", "Should have battery level");

    // Each line should be in VAR=value format (no colons like YAML)
    ASSERT_NOT_CONTAINS(output, ": ", "ENV format should not have YAML-style colons");

    std::cout << "    ✓ CLI ENV output is correct" << std::endl;
}

void testCliEnvShellSafe()
{
    std::cout << "  Testing CLI ENV output is shell-safe..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o env 2>&1");

    // Verify keys are uppercase and use underscores
    // Check that variable names only contain valid shell characters
    std::istringstream iss(output);
    std::string line;
    while (std::getline(iss, line)) {
        if (line.empty() || line[0] == '#')
            continue;

        size_t eqPos = line.find('=');
        if (eqPos == std::string::npos)
            continue;

        std::string key = line.substr(0, eqPos);

        // Key should only contain A-Z, 0-9, _
        for (char c : key) {
            bool valid = (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_';
            ASSERT_TRUE(valid, "ENV variable name should be shell-safe: " + key);
        }
    }

    std::cout << "    ✓ CLI ENV output is shell-safe" << std::endl;
}

// ============================================================================
// Action + Extended Output Tests
// ============================================================================

void testCliActionOnlyOmitsUnrequestedInfo()
{
    std::cout << "  Testing action-only invocation omits info not explicitly requested..." << std::endl;

    // -s (sidetone) is an action; battery/chatmix were not asked for, so an
    // extended-format invocation should not pay for reading them.
    std::string output = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -s 20 -o json 2>&1");

    ASSERT_CONTAINS(output, "\"actions\":", "Should have actions array");
    ASSERT_NOT_CONTAINS(output, "\"battery\":", "Battery info should be omitted when not requested");
    ASSERT_NOT_CONTAINS(output, "\"chatmix\":", "Chatmix info should be omitted when not requested");

    std::cout << "    ✓ Action-only invocation omits unrequested info" << std::endl;
}

void testCliActionWithExplicitInfoKeepsOnlyThat()
{
    std::cout << "  Testing action + explicit info request keeps only that info..." << std::endl;

    // -b is explicitly requested alongside the -s action; chatmix was not
    // asked for and should still be omitted.
    std::string output = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -b -s 20 -o json 2>&1");

    ASSERT_CONTAINS(output, "\"actions\":", "Should have actions array");
    ASSERT_CONTAINS(output, "\"battery\":", "Explicitly requested battery info should be present");
    ASSERT_NOT_CONTAINS(output, "\"chatmix\":", "Chatmix info should be omitted when not requested");

    std::cout << "    ✓ Action with explicit info request keeps only that info" << std::endl;
}

void testCliPureQueryStillReturnsAllInfo()
{
    std::cout << "  Testing pure query (no action) still returns all extended info..." << std::endl;

    // No action requested, so the extended-format default of reading every
    // supported info capability still applies.
    std::string output = exec(HEADSETCONTROL_EXE " --test-device -o json 2>&1");

    ASSERT_CONTAINS(output, "\"battery\":", "Pure query should still report battery");
    ASSERT_CONTAINS(output, "\"chatmix\":", "Pure query should still report chatmix");

    std::cout << "    ✓ Pure query still returns all extended info" << std::endl;
}

// ============================================================================
// Device Selection Tests
// ============================================================================

void testCliActionWithoutDeviceFilter()
{
    std::cout << "  Testing action without -d is refused only when several devices are found..." << std::endl;

    // --test-device adds a single mock, so CI only sees the one-device case.
    // With a real headset attached the action has to be refused for every
    // device instead of being set on all of them.
    std::string output   = exec(HEADSETCONTROL_EXE " --test-device -l 1 -o json 2>&1");
    std::string standard = exec(HEADSETCONTROL_EXE " --test-device -l 1 2>&1");

    auto actions_start = output.find("\"actions\":");
    auto actions_end   = output.find("\"device_count\":");
    ASSERT_TRUE(actions_start != std::string::npos && actions_end != std::string::npos && actions_start < actions_end,
        "Should have an actions array before device_count");
    std::string actions = output.substr(actions_start, actions_end - actions_start);

    if (output.find("\"device_count\": 1,") != std::string::npos) {
        ASSERT_CONTAINS(actions, "\"status\": \"success\"", "A single device should not need -d");
        ASSERT_CONTAINS(standard, "Successfully set lights!", "A single device should not need -d");
        std::cout << "    ✓ Action without -d runs on a single device" << std::endl;
        return;
    }

    ASSERT_CONTAINS(actions, "Multiple devices, specify with -d", "Action should be refused without -d");
    ASSERT_NOT_CONTAINS(actions, "\"status\": \"success\"", "No device should be set without -d");
    ASSERT_CONTAINS(standard, "Multiple devices, specify with -d", "Standard output should report the refusal");
    ASSERT_NOT_CONTAINS(standard, "Successfully set", "No device should be set without -d");

    std::cout << "    ✓ Action without -d is refused on multiple devices" << std::endl;
}

// ============================================================================
// Standard Output Tests
// ============================================================================

void testCliStandardOutput()
{
    std::cout << "  Testing CLI standard output with --test-device..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b 2>&1");

    // Standard output should be human-readable
    ASSERT_CONTAINS(output, "Found", "Should indicate device found");
    ASSERT_CONTAINS(output, "Battery", "Should show battery info");
    ASSERT_CONTAINS(output, "HeadsetControl Test device", "Should show device name");

    std::cout << "    ✓ CLI standard output is correct" << std::endl;
}

void testCliStandardBatteryDetails()
{
    std::cout << "  Testing CLI standard output battery details..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b 2>&1");

    // Should show battery details
    ASSERT_CONTAINS(output, "Status:", "Should show battery status label");
    ASSERT_CONTAINS(output, "Level:", "Should show battery level label");
    ASSERT_CONTAINS(output, "%", "Should show percentage");

    // Test device returns extended battery info
    ASSERT_CONTAINS(output, "Voltage:", "Should show voltage");
    ASSERT_CONTAINS(output, "mV", "Should show millivolts unit");

    std::cout << "    ✓ CLI standard battery details are correct" << std::endl;
}

void testCliStandardChargingWithoutLevel()
{
    std::cout << "  Testing CLI standard output for charging with no level..." << std::endl;

    // Profile 8 charges without having reported a level, as the Sony PULSE 3D
    // and the two HyperX devices do. -1 is not a reading, so no Level line.
    //
    // -d restricts this to the test device. Without it a real headset plugged
    // into the machine running the suite is enumerated too and prints its own
    // Level line, which this asserts the absence of.
    std::string output = exec(HEADSETCONTROL_EXE " --test-device 8 -d 0xf00b:0xa00c -b 2>&1");

    ASSERT_CONTAINS(output, "BATTERY_CHARGING", "Charging status should still be shown");
    ASSERT_NOT_CONTAINS(output, "Level:", "An unknown level should not be printed");
    ASSERT_NOT_CONTAINS(output, "-1", "-1 should never reach the output");

    // A charging headset that does report a level still prints it
    std::string with_level = exec(HEADSETCONTROL_EXE " --test-device 2 -d 0xf00b:0xa00c -b 2>&1");
    ASSERT_CONTAINS(with_level, "BATTERY_CHARGING", "Profile 2 is charging too");
    ASSERT_CONTAINS(with_level, "Level: 50%", "A known level is still printed");

    // The structured formats keep -1 as the sentinel, so consumers are unaffected
    std::string json = exec(HEADSETCONTROL_EXE " --test-device 8 -d 0xf00b:0xa00c -b -o json 2>&1");
    ASSERT_CONTAINS(json, "\"level\": -1", "JSON keeps the -1 sentinel");

    std::cout << "    ✓ Charging without a level omits the level line" << std::endl;
}

void testCliStandardNoArgs()
{
    std::cout << "  Testing CLI standard output with no args..." << std::endl;

    // When no action is specified, should show version info and hint
    std::string output = exec(HEADSETCONTROL_EXE " --test-device 2>&1");

    // Should show attribution and hint
    ASSERT_CONTAINS(output, "HeadsetControl", "Should show HeadsetControl");
    ASSERT_CONTAINS(output, "Sapd", "Should show author");
    ASSERT_CONTAINS(output, "-h", "Should hint about help");

    std::cout << "    ✓ CLI standard no-args output is correct" << std::endl;
}

void testCliMicStatusOutputs()
{
    std::cout << "  Testing microphone status in all output formats..." << std::endl;

    const std::string base = HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --microphone-attachment-status --microphone-mute-status -o ";

    std::string json = exec((base + "json 2>&1").c_str());
    ASSERT_CONTAINS(json, "\"mic_attached\": 1", "JSON should have mic_attached");
    ASSERT_CONTAINS(json, "\"mic_muted\": 0", "JSON should have mic_muted");

    std::string yaml = exec((base + "yaml 2>&1").c_str());
    ASSERT_CONTAINS(yaml, "mic_attached: 1", "YAML should have mic_attached");
    ASSERT_CONTAINS(yaml, "mic_muted: 0", "YAML should have mic_muted");

    std::string env = exec((base + "env 2>&1").c_str());
    ASSERT_CONTAINS(env, "DEVICE_0_MIC_ATTACHED=1", "ENV should have mic_attached");
    ASSERT_CONTAINS(env, "DEVICE_0_MIC_MUTED=0", "ENV should have mic_muted");

    std::string standard = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --microphone-attachment-status --microphone-mute-status 2>&1");
    ASSERT_CONTAINS(standard, "Mic: attached", "standard output should show attachment status");
    ASSERT_CONTAINS(standard, "Mic mute: unmuted", "standard output should show mute status");

    std::cout << "    OK microphone status outputs" << std::endl;
}

void testCliSidetoneStatusOutputs()
{
    std::cout << "  Testing sidetone status in all output formats..." << std::endl;

    const std::string base = HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -s -o ";

    std::string json = exec((base + "json 2>&1").c_str());
    ASSERT_CONTAINS(json, "\"sidetone\": {", "JSON should have sidetone object");
    ASSERT_CONTAINS(json, "\"level\": 85", "JSON should have normalized level");
    ASSERT_CONTAINS(json, "\"device_level\": 2", "JSON should have native level");
    ASSERT_CONTAINS(json, "\"name\": \"Medium\"", "JSON should have named level");

    std::string yaml = exec((base + "yaml 2>&1").c_str());
    ASSERT_CONTAINS(yaml, "sidetone:", "YAML should have sidetone object");
    ASSERT_CONTAINS(yaml, "device_level: 2", "YAML should have native level");
    ASSERT_CONTAINS(yaml, "name: \"Medium\"", "YAML should have named level");

    std::string env = exec((base + "env 2>&1").c_str());
    ASSERT_CONTAINS(env, "DEVICE_0_SIDETONE_LEVEL=85", "ENV should have normalized level");
    ASSERT_CONTAINS(env, "DEVICE_0_SIDETONE_DEVICE_LEVEL=2", "ENV should have native level");
    ASSERT_CONTAINS(env, "DEVICE_0_SIDETONE_NAME=\"Medium\"", "ENV should have named level");

    std::string standard = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -s 2>&1");
    ASSERT_CONTAINS(standard, "Sidetone: Medium (85; device level 2)",
        "standard output should show normalized, native, and named level");

    std::string long_query = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --sidetone 2>&1");
    ASSERT_CONTAINS(long_query, "Sidetone: Medium (85; device level 2)",
        "long sidetone option without a value should query");

    std::string short_set = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -s 64 2>&1");
    ASSERT_CONTAINS(short_set, "Successfully set sidetone!",
        "short sidetone option with a value should set");

    std::string long_set = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --sidetone 64 2>&1");
    ASSERT_CONTAINS(long_set, "Successfully set sidetone!",
        "long sidetone option with a value should set");

    std::string help = exec(HEADSETCONTROL_EXE " --help-all 2>&1");
    ASSERT_CONTAINS(help, "-s, --sidetone [LEVEL]",
        "help should document the optional sidetone level");
    ASSERT_NOT_CONTAINS(help, "--sidetone-status",
        "help should not expose a separate sidetone status option");

    std::cout << "    ✓ Sidetone status output is correct" << std::endl;
}

void testCliHeadsetVolumeOutputs()
{
    std::cout << "  Testing headset volume in all output formats..." << std::endl;

    // -d keeps the set requests below away from any real headset that is connected
    const std::string base = HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --volume -o ";

    std::string json = exec((base + "json 2>&1").c_str());
    ASSERT_CONTAINS(json, "\"headset_volume\": {", "JSON should have headset_volume object");
    ASSERT_CONTAINS(json, "\"level\": 77", "JSON should have normalized level");
    ASSERT_CONTAINS(json, "\"device_level\": 15", "JSON should have native level");
    ASSERT_CONTAINS(json, "\"readable_capabilities\": [", "JSON should list readable capabilities");
    ASSERT_CONTAINS(json, "\"CAP_HEADSET_VOLUME\"", "JSON should list headset volume as readable");

    std::string yaml = exec((base + "yaml 2>&1").c_str());
    ASSERT_CONTAINS(yaml, "headset_volume:", "YAML should have headset_volume object");
    ASSERT_CONTAINS(yaml, "device_level: 15", "YAML should have native level");
    ASSERT_CONTAINS(yaml, "readable_capabilities:", "YAML should list readable capabilities");

    std::string env = exec((base + "env 2>&1").c_str());
    ASSERT_CONTAINS(env, "DEVICE_0_HEADSET_VOLUME_LEVEL=77", "ENV should have normalized level");
    ASSERT_CONTAINS(env, "DEVICE_0_HEADSET_VOLUME_DEVICE_LEVEL=15", "ENV should have native level");
    ASSERT_CONTAINS(env, "DEVICE_0_READABLE_CAPABILITIES_AMOUNT=2", "ENV should count readable capabilities");

    std::string standard = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --volume 2>&1");
    ASSERT_CONTAINS(standard, "Headset volume: 77 (device level 15)",
        "volume option without a value should query");

    std::string set = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --volume 20 2>&1");
    ASSERT_CONTAINS(set, "Successfully set headset volume!", "volume option with a value should set");

    std::string set_json = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --volume 20 -o json 2>&1");
    ASSERT_NOT_CONTAINS(set_json, "\"headset_volume\":", "a set should not also read the volume back");

    std::string query = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -o json 2>&1");
    ASSERT_CONTAINS(query, "\"headset_volume\": {", "a pure query should read readable capabilities");

    std::string limited = exec(HEADSETCONTROL_EXE " --test-device 10 -d 0xf00b:0xa00c --volume 2>&1");
    ASSERT_CONTAINS(limited, "doesn't support volume", "a device without the capability should say so");

    std::string write_only = exec(HEADSETCONTROL_EXE " --test-device 6 -d 0xf00b:0xa00c --volume 2>&1");
    ASSERT_CONTAINS(write_only, "can't read back volume", "a write-only capability should say it can't be read");

    std::string write_only_set = exec(HEADSETCONTROL_EXE " --test-device 6 -d 0xf00b:0xa00c --volume 20 2>&1");
    ASSERT_CONTAINS(write_only_set, "Successfully set headset volume!", "a write-only capability should still set");

    std::string write_only_query = exec(HEADSETCONTROL_EXE " --test-device 6 -d 0xf00b:0xa00c -o json 2>&1");
    ASSERT_NOT_CONTAINS(write_only_query, "\"headset_volume\":", "a pure query should skip unreadable capabilities");

    std::string write_only_env = exec(HEADSETCONTROL_EXE " --test-device 6 -d 0xf00b:0xa00c -o env 2>&1");
    ASSERT_CONTAINS(write_only_env, "DEVICE_0_READABLE_CAPABILITIES_AMOUNT=1", "only sidetone should be listed as readable");

    std::cout << "    OK headset volume outputs" << std::endl;
}

void testCliLightColorOutputs()
{
    std::cout << "  Testing light color in all output formats..." << std::endl;

    const std::string base = HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --light-color 000000 -o ";

    // Black packs to 0, and every format must still report it
    std::string json = exec((base + "json 2>&1").c_str());
    ASSERT_CONTAINS(json, "\"capability\": \"CAP_LIGHT_COLOR\"", "JSON should have the light color action");
    ASSERT_CONTAINS(json, "\"value\": 0", "JSON should keep black's value");
    ASSERT_CONTAINS(json, "\"color\": \"#000000\"", "JSON should have the color");

    std::string yaml = exec((base + "yaml 2>&1").c_str());
    ASSERT_CONTAINS(yaml, "value: 0", "YAML should keep black's value");
    ASSERT_CONTAINS(yaml, "color: \"#000000\"", "YAML should have the color");

    std::string env = exec((base + "env 2>&1").c_str());
    ASSERT_CONTAINS(env, "ACTION_0_VALUE=0", "ENV should keep black's value");
    ASSERT_CONTAINS(env, "ACTION_0_COLOR=\"#000000\"", "ENV should have the color");

    std::string standard = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c --light-color ff8000 2>&1");
    ASSERT_CONTAINS(standard, "Successfully set light color!", "standard output should confirm");

    // With -l on the same command line, the color is applied last
    std::string both = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -l 0 --light-color \"#FF8000\" -o json 2>&1");
    ASSERT_CONTAINS(both, "\"value\": 16744448", "value should pack 0xRRGGBB");
    ASSERT_CONTAINS(both, "\"color\": \"#ff8000\"", "color should be normalised to lower case");
    const auto lights_at = both.find("\"CAP_LIGHTS\"");
    const auto color_at  = both.find("\"CAP_LIGHT_COLOR\"");
    ASSERT_TRUE(lights_at != std::string::npos && color_at != std::string::npos && lights_at < color_at,
        "-l should run before --light-color");

    // -l on its own keeps its existing output: no value for 0
    std::string lights_off = exec(HEADSETCONTROL_EXE " --test-device -d 0xf00b:0xa00c -l 0 -o json 2>&1");
    ASSERT_NOT_CONTAINS(lights_off, "\"value\"", "-l 0 should still omit value");

    std::string invalid = exec(HEADSETCONTROL_EXE " --test-device --light-color 12345 2>&1");
    ASSERT_CONTAINS(invalid, "format: RRGGBB or #RRGGBB", "invalid color should be rejected");

    std::string help = exec(HEADSETCONTROL_EXE " --help-all 2>&1");
    ASSERT_CONTAINS(help, "--light-color <RRGGBB>", "help should document --light-color");

    std::cout << "    ✓ Light color output is correct" << std::endl;
}

// ============================================================================
// Short Output Tests
// ============================================================================

void testCliShortOutput()
{
    std::cout << "  Testing CLI short output with --test-device..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b --short-output 2>&1");

    // Short output should be minimal - just a number for battery
    // Should contain a number (battery level)
    bool hasNumber = false;
    for (char c : output) {
        if (c >= '0' && c <= '9') {
            hasNumber = true;
            break;
        }
    }
    ASSERT_TRUE(hasNumber, "Short output should contain battery level number");

    // Should NOT contain verbose text
    ASSERT_NOT_CONTAINS(output, "Found", "Short output should not have verbose text");
    ASSERT_NOT_CONTAINS(output, "Battery:", "Short output should not have labels");

    std::cout << "    ✓ CLI short output is correct" << std::endl;
}

void testCliShortBattery()
{
    std::cout << "  Testing CLI short battery output..." << std::endl;

    // Short output for battery should just be the number
    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o short 2>&1");

    // Should contain just a battery level number (42 from test device)
    ASSERT_CONTAINS(output, "42", "Short battery output should show level 42");

    // Should NOT contain verbose labels
    ASSERT_NOT_CONTAINS(output, "Battery:", "Short output should not have labels");
    ASSERT_NOT_CONTAINS(output, "Status:", "Short output should not have labels");

    std::cout << "    ✓ CLI short battery output is correct" << std::endl;
}

void testCliShortDeprecationWarning()
{
    std::cout << "  Testing CLI short output deprecation warning..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b --short-output 2>&1");

    // Short output should include deprecation warning on stderr, naming SHORT
    // itself (not -o, which is how you'd reach json/yaml/env too) as the
    // deprecated part.
    ASSERT_CONTAINS(output, "deprecated", "Short output should show deprecation warning");
    ASSERT_CONTAINS(output, "SHORT", "Warning should name SHORT as the deprecated format");

    std::cout << "    ✓ CLI short deprecation warning is present" << std::endl;
}

void testCliOutputShortDeprecationWarning()
{
    std::cout << "  Testing CLI '-o short' deprecation warning..." << std::endl;

    // -o short is an alias for --short-output and should carry the same
    // warning, worded so it's clear SHORT (not -o) is what's deprecated.
    std::string output = exec(HEADSETCONTROL_EXE " --test-device -b -o short 2>&1");

    ASSERT_CONTAINS(output, "deprecated", "-o short should show deprecation warning");
    ASSERT_CONTAINS(output, "SHORT", "Warning should name SHORT as the deprecated format");

    std::cout << "    ✓ CLI '-o short' deprecation warning is present" << std::endl;
}

void testCliHelpHidesShortOutput()
{
    std::cout << "  Testing CLI help no longer advertises short output..." << std::endl;

    std::string output = exec(HEADSETCONTROL_EXE " --test-device --help-all 2>&1");

    ASSERT_NOT_CONTAINS(output, "short-output", "Help should not advertise the deprecated --short-output flag");
    ASSERT_NOT_CONTAINS(output, "standard, short", "Help should not list short as an -o output format choice");

    std::cout << "    ✓ CLI help hides short output" << std::endl;
}

// ============================================================================
// Test Runner
// ============================================================================

void runAllCliOutputTests()
{
    std::cout << "\n╔══════════════════════════════════════════════════════╗" << std::endl;
    std::cout << "║           CLI Output Integration Tests               ║" << std::endl;
    std::cout << "╚══════════════════════════════════════════════════════╝\n"
              << std::endl;

    int passed = 0;
    int failed = 0;

    auto runTest = [&](const char* name, void (*test)()) {
        try {
            test();
            passed++;
        } catch (const TestFailure& e) {
            std::cerr << "    ✗ FAILED: " << e.what() << std::endl;
            failed++;
        } catch (const std::exception& e) {
            std::cerr << "    ✗ ERROR: " << e.what() << std::endl;
            failed++;
        }
    };

    std::cout << "=== JSON CLI Tests ===" << std::endl;
    runTest("JSON Output", testCliJsonOutput);
    runTest("JSON Valid Structure", testCliJsonValid);

    std::cout << "\n=== YAML CLI Tests ===" << std::endl;
    runTest("YAML Output", testCliYamlOutput);
    runTest("YAML Indentation", testCliYamlIndentation);

    std::cout << "\n=== ENV CLI Tests ===" << std::endl;
    runTest("ENV Output", testCliEnvOutput);
    runTest("ENV Shell-Safe", testCliEnvShellSafe);

    std::cout << "\n=== Action + Extended Output Tests ===" << std::endl;
    runTest("Action-Only Omits Unrequested Info", testCliActionOnlyOmitsUnrequestedInfo);
    runTest("Action With Explicit Info", testCliActionWithExplicitInfoKeepsOnlyThat);
    runTest("Pure Query Still Returns All Info", testCliPureQueryStillReturnsAllInfo);

    std::cout << "\n=== Device Selection Tests ===" << std::endl;
    runTest("Action Without Device Filter", testCliActionWithoutDeviceFilter);

    std::cout << "\n=== Standard Output Tests ===" << std::endl;
    runTest("Standard Output", testCliStandardOutput);
    runTest("Standard Battery Details", testCliStandardBatteryDetails);
    runTest("Standard Charging Without Level", testCliStandardChargingWithoutLevel);
    runTest("Standard No Args", testCliStandardNoArgs);
    runTest("Sidetone Status Outputs", testCliSidetoneStatusOutputs);
    runTest("Mic Status Outputs", testCliMicStatusOutputs);
    runTest("Headset Volume Outputs", testCliHeadsetVolumeOutputs);
    runTest("Light Color Outputs", testCliLightColorOutputs);

    std::cout << "\n=== Short Output Tests ===" << std::endl;
    runTest("Short Output", testCliShortOutput);
    runTest("Short Battery", testCliShortBattery);
    runTest("Short Deprecation Warning", testCliShortDeprecationWarning);
    runTest("Output Short Deprecation Warning", testCliOutputShortDeprecationWarning);
    runTest("Help Hides Short Output", testCliHelpHidesShortOutput);

    std::cout << "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" << std::endl;
    std::cout << "CLI Output Tests: " << passed << " passed, " << failed << " failed" << std::endl;
    std::cout << "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" << std::endl;

    if (failed > 0) {
        throw std::runtime_error("Some CLI output tests failed");
    }
}

} // namespace headsetcontrol::testing
